<h1 align="center">
  💻<br>iuricode | Design e tecnologia
</h1>

![Resultado final do projeto](assets/image/preview.png)

<h4 align="center"><a href="https://www.iuricode.com/">Clique para visitar o projeto</a></h4>

## 📚 Seções

O site é composto por seis seções:

- **Home:** Nele temos uma breve apresentação;
- **Quem sou:** Nessa seção tenho uma descrição dizendo um pouco sobre quem sou;
- **Projetos:** Apresenta alguns projetos desenvolvidos e com link direto para os respectivos códigos no GitHub;
- **FAQ:** Perguntas frequentes para tirar dúvidas.

---

## 💼 Tecnologias utilizadas

Para o desenvolvimento deste site utilizei as seguintes tecnologias:

- HTML;
- Sass;
- JavaScript;

---

## Disponível para freelas - #OpenToWork 🚀

Atualmente estou aberto para oportunidades como Desenvolvedor Frontend e UI/UX Designer. Se você precisa de alguém para transformar ideias em interfaces bonitas, responsivas e funcionais, podemos trabalhar juntos!

📬 Entre em contato:
📧 iuricold99@gmail.com
💼 [Linkedin](https://www.linkedin.com/in/iuricode/)
